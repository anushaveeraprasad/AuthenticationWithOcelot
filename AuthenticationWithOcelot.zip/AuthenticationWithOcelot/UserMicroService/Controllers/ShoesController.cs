﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ShoeMicroService.Interface;
using ShoeMicroService.Models;
using System.Data.SqlClient;
using Dapper;
using Authentication.Classes;

namespace ShoeMicroService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ShoesController : ControllerBase
    {
        private readonly IConfiguration _config;
        //private readonly IConfiguration _config;
        public ShoesController(IConfiguration configuration)
        {
            _config = configuration;
        }
        public string getTokenFromCookie()
        {
            return Request.Cookies["AuthToken"];
        }

        [HttpGet]
        public async  Task<IActionResult> GetAllShoes()
        {
            string jwtToken= getTokenFromCookie();
            if(jwtToken == null)
            {
                return NotFound("Token not found");
            }
            else if(_config.CheckTokenExpiration(jwtToken))
            {
                using var connectionString = new SqlConnection(_config.GetConnectionString("DefaultConnection"));
                var shoes = await connectionString.QueryAsync<Shoe>("Select * from Shoe");
                return shoes != null ? Ok(shoes) : NotFound("No data");
            }
            return BadRequest("Token has expired. Please login again");
   
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> RemoveShoes(int id)
        {
            using var connectionString = new SqlConnection(_config.GetConnectionString("DefaultConnection"));
            var result= await connectionString.ExecuteAsync($"Delete from Shoe where id={id}");
            return result < 1 ? BadRequest("Unable to delete teh shoe specified") : Ok("Shoe was deleted successfully");
        }
    }
}
