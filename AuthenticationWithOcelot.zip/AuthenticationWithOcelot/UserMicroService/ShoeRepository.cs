﻿using ShoeMicroService.Interface;
using ShoeMicroService.Models;
using System.Data.SqlClient;
using System.Text.Json.Serialization;

namespace ShoeMicroService
{
    public class ShoeRepository: IShoeRepository
    {
        
        private static List<Shoe> _shoes = new()
        {
            new()
            {
                Id = 1,
                Name = "Colorblock",
                Brand = "Nike",
                Price = 5677
            },
            new()
            {
                Id = 2,
                Name = "Vaporfly",
                Brand = "New Balance",
                Price = 7899
            },
            new()
            {
                Id = 3,
                Name = "Ride 15",
                Brand = "Puma",
                Price = 2098
            }
        };
      
        [Obsolete(" Use GetAllShoes")]
        public List<Shoe> GetShoes() => _shoes;
        [Obsolete("Use RemoveShoes")]
        public bool DeleteShoe(int id)
        {
            var shoe = _shoes.FirstOrDefault(s => s.Id == id);
            if (shoe is not null)
            {
                return _shoes.Remove(shoe);
            }
            return false;
        }



    }
}
