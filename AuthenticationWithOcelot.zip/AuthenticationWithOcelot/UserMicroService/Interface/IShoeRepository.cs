﻿using ShoeMicroService.Models;

namespace ShoeMicroService.Interface
{
    public interface IShoeRepository
    {
        public List<Shoe> GetShoes();
        public bool DeleteShoe(int id);

    }
}
