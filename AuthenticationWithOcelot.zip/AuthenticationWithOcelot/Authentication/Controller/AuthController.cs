﻿using Authentication.Classes;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace Authentication.Controller
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly JwtTokenService _jwtTokenService;
        public AuthController(JwtTokenService jwtTokenService)
        {
            _jwtTokenService = jwtTokenService;
        }
        [HttpPost("login")]
        public IActionResult Login([FromBody] User user)
        {
            if (user is null)
            {
                return BadRequest("Invalid client request");
            }
            //if (user.UserName == "admin" && user.Password == "password")
            //{
            var authToken = _jwtTokenService.GenerateAuthToken(user);
            if(authToken.Value is not null)
            {
                //var secretKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(JwtExtensions.SecurityKey));
                //var signinCredentials = new SigningCredentials(secretKey, SecurityAlgorithms.HmacSha256);
                //var claims = new[]
                //{
                //    new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                //    new Claim(JwtRegisteredClaimNames.Name, user.UserName.ToString()),
                //    new Claim("Role",user.Role)
                //};
                //var tokeOptions = new JwtSecurityToken(
                //    issuer: "https://localhost:7276",
                //    audience: "https://localhost:7276",
                //    claims: claims,
                //    expires: DateTime.Now.AddMinutes(5),
                //    signingCredentials: signinCredentials
                //);
                //var tokenString = new JwtSecurityTokenHandler().WriteToken(tokeOptions);
                var cookieOptions = new CookieOptions
                {
                    Expires = DateTime.UtcNow.AddMinutes(5),
                    HttpOnly = true,  // Ensures the cookie is accessible only through HTTP requests
                    SameSite = SameSiteMode.Strict,
                    Path = "/"
                };
                Response.Cookies.Append("AuthToken", authToken.Value, cookieOptions);
                return Ok(new AuthenticatedResponse { Token = authToken.Value });
            }
            return Unauthorized("Invalid Credentials");
        }
    }
}
