﻿using Dapper;
using Microsoft.AspNetCore.Authentication;
using Microsoft.IdentityModel.Tokens;
using System.Data.SqlClient;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.AspNetCore.Http;

namespace Authentication.Classes
{
    public class JwtTokenService
    {
        private readonly IConfiguration _config;
        //public static string GlobalToken { get; set; }
        public JwtTokenService(IConfiguration configuration)
        {
            _config = configuration;
        }

        public AuthenticationToken? GenerateAuthToken(User loginModel)
        {
            using var connectionString = new SqlConnection(_config.GetConnectionString("DefaultConnection"));
            var user = connectionString.QueryFirstOrDefault<User>($"Select * from [User] where lower(username)='{loginModel.UserName.ToLower()}' and password='{loginModel.Password}'");

            if (user is null)
            {
                return null;
            }

            var secretKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(JwtExtensions.SecurityKey));
            var signingCredentials = new SigningCredentials(secretKey, SecurityAlgorithms.HmacSha256);
            var expirationTimeStamp = DateTime.Now.AddMinutes(5);

            var claims = new List<Claim>
        {
            new Claim(JwtRegisteredClaimNames.Name, user.UserName),
            new Claim("Role", user.Role)
        };

            var tokenOptions = new JwtSecurityToken(
                issuer: "https://localhost:7276",
                audience: "https://localhost:7276",
                claims: claims,
                expires: expirationTimeStamp,
                signingCredentials: signingCredentials
            );

            var tokenString = new JwtSecurityTokenHandler().WriteToken(tokenOptions);
            return new AuthenticationToken() { Value=tokenString};
            //return new AuthenticationToken(tokenString, (int)expirationTimeStamp.Subtract(DateTime.Now).TotalSeconds);
        }
    }
}
