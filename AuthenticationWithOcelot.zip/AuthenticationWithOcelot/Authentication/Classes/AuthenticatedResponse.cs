﻿namespace Authentication.Classes
{
    public class AuthenticatedResponse
    {
        public string? Token { get; set; }
    }
}
